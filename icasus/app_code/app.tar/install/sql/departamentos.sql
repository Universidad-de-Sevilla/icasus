INSERT INTO `entidad` VALUES  
(61,'Aula de la Experiencia'),
(62,'entro de Documentacion Europea'),
(63,'Consejo de Alumnos Universidad Sevilla'),
(64,'Instituto Andaluz Interun. Criminologia'),
(65,'Instituto Univ.Arquitectura y CC.Const.'),
(66,'Instituto Univ.Investigacion Matemáticas');
