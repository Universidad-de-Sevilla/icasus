<?php
//---------------------------------------------------------------------------------------------------
// Proyecto: Icasus (http://wiki.us.es/icasus/)
// Archivo: valor_grabar.php
// Desarrolladores: Juanan Ruiz (juanan@us.es), Jesús Martín (jjmc@us.es) 
//---------------------------------------------------------------------------------------------------
// Descripcion: Graba en la base de dato el nuevo valor con los datos que vienen del formulario 
//---------------------------------------------------------------------------------------------------

global $smarty;
global $usuario;
global $plantilla;

$valor = sanitize($_POST["valor"],2);

$v = new valor();
$v->load("id = ".sanitize($_POST["id2"],2));
$v->id_usuario = $usuario->id;
$v->valor = $valor;
$v->fecha_recogida = date("Y-m-d");
$v->save();
?>
