<?php
//---------------------------------------------------------------------------------------------------
// Proyecto: Icasus (http://wiki.us.es/icasus/)
// Archivo: cuadromando_crear.php
// Tipo: controlador
// Desarrolladores: Juanan Ruiz (juanan@us.es), Jesus Martin (jjmc@us.es)
//---------------------------------------------------------------------------------------------------
// Descripcion: Prepara los datos para mostrar el formulario que permite crear un nuevo cuadro de mando
//---------------------------------------------------------------------------------------------------

//require_once("/var/www/cascara/cascara_core/lib/phpExcel/PHPExcel.php");
require_once("/var/www/wiki/icasus/lib/phpExcel/PHPExcel/IOFactory.php");
require_once("/var/www/wiki/icasus/lib/phpExcel/PHPExcel/RichText.php");

$ado_entidad = new ado_entidad();
$entidades = $ado_entidad->informe_entidad_indicador('UE01-');

//inicio y titulo de la hoja 
$excel = new PHPExcel();

$excel->getActiveSheet()->setTitle("Indicadores ".date("d-m-Y"));
$excel->getActiveSheet()->setCellValue('A1','Unidad');
$excel->getActiveSheet()->setCellValue('B1','Indicador');
$excel->getActiveSheet()->setCellValue('C1','Valor');
$excel->getActiveSheet()->setCellValue('D1','Fecha');

$i = 2;
foreach($entidades as $entidad)
{
	$excel->getActiveSheet()->setCellValue('A'.$i,$entidad->nombre);
	$i = $i + 1;
	foreach($entidad->indicadores as $indicador)
	{
		$excel->getActiveSheet()->setCellValue('B'.$i,$indicador->nombre);
		$i = $i +1;
		foreach($indicador->valores as $valor)
		{
		$excel->getActiveSheet()->setCellValue('C'.$i,$valor->valor);
		$excel->getActiveSheet()->setCellValue('D'.$i,date("d-m-Y",$valor->fecha_entrada));
		$i = $i +1;
		}
	$i = $i +1;
	}	
$i = $i +1;
}
$excel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$excel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$excel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$excel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);

$excel->getActiveSheet()->getStyle('A1:D1')->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_WHITE);
$excel->getActiveSheet()->getStyle('A1:D1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
$excel->getActiveSheet()->getStyle('A1:D1')->getFill()->getStartColor()->setARGB('FF990000');


$excelBinaryWriter = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
$archivo = 'informes/indicadores_dpto.xls';
$excelBinaryWriter->save($archivo);

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename='.basename($archivo));
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . filesize($archivo));
ob_clean();
flush();
readfile($archivo);
?>
