<?php
//---------------------------------------------------------------------------------------------------
// Proyecto: Icasus (http://wiki.us.es/icasus/)
// Archivo: config.php
// Tipo: fichero de configuracion
// Desarrolladores: Juanan Ruiz (juanan@us.es), Jesús Martín (jjmc@us.es)
//---------------------------------------------------------------------------------------------------
// Descripcion: Variables globales para el proyecto icasus
// Debe incluirse en todos los archivos php del proyecto.
// Modifica este archivo para que se ajuste a tus necesidades concretas.
//---------------------------------------------------------------------------------------------------

// Todas las constantes declaradas en este fichero empiezan 
// por IC (de icasus) para denotar su caracter global a toda la aplicación

//Conexion a la base de datos
define('IC_DB_HOST','localhost');
define('IC_DB_LOGIN','root');//escriba el usuario de la BD.
define('IC_DB_CLAVE','');//escriba la clave del usuario.
define('IC_DB_DATABASE','icasus_bbtk');//escriba la BD.

// Tema que vamos a utilizar para definir la apariencia del sitio
define('IC_THEME', 'usevilla');

// Establece que configuración SSO
// Si en servidor de desarrollo (usuarios pruebapas, pruebaalumno y pruebapdi). Descomentar 'pre_11'.
// Si en servidor de producción ó preproducción (usuarios reales). Descomentar 'prod_1013'.

//define('CONFIG_PACK', 'prod_1013');
define('CONFIG_PACK', 'pre_11');

// Que tipo de autenticación va a uilizarse (login_sso ó login_basico).
define('IC_TIPO_LOGIN','login_basico');

//Directorios
define('IC_DIR_BASE','/Applications/XAMPP/xamppfiles/htdocs/icasus/');
?>
