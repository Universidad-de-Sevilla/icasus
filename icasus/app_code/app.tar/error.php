<?php
global $smarty;
global $plantilla;

$smarty->assign('_nombre_pagina','Se ha producido un error');
$plantilla = 'error.tpl';
?>
